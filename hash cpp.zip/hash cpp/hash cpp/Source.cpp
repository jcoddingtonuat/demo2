// Hash hashT using chains
#include<iostream> 
#include <list> 
using namespace std;

class HT
{
	int numIndexes;
	list<int>* hashT;

public:
	HT(int V); // Constructor 

	void insertItem(int x);


	void findItem(int key);


	int hash(int x) 
	{
		return (x % 2);
	}

	void displayHash();
};

HT::HT(int b)
{
	this->numIndexes = b;
	hashT = new list<int>[numIndexes];
}

void HT::displayHash()
{
	for (int i = 0; i < numIndexes; i++)
	{
		cout << i;
		for (auto x : hashT[i])
			cout << " --> " << x;
		cout << endl;
	}
}

void HT::insertItem(int key)
{
	int index = hash(key);
	hashT[index].push_back(key);
}

void HT::findItem(int key)
{
	// get the hash index of key 
	int index = hash(key);

	// find the key in (inex)th list 
	list <int> ::iterator i;
	for (i = hashT[index].begin(); i != hashT[index].end(); i++)
	{
		if (*i == key)
			cout << "key found" << endl;
	}

	


}


// Driver program 
int main()
{

	int n = 2;
	int rnd;
//	int values[10];
	/* initialize random seed: */
	srand(time(NULL));

	/* generate secret number between 1 and 10: */

	
	HT h(n);
	for (int i = 0; i < n-1; i++)
	{
		rnd = rand() % 10 + 1;
		h.insertItem(rnd);


	}
	// item for deleting
	h.insertItem(42);

	h.displayHash();
	h.findItem(42);
	// display the Hash hashT 



	return 0;
}
